# Rummy King Android starter (v0.2.0)

This project wraps the local HTML prototype in an Android WebView. It is a free-to-play practice demo with fictional points, XP levels, a daily reward, local progress, card drawing/discarding, sorting, and a simplified hand checker. No real-money gambling, purchases, cash prizes, or withdrawals are implemented.

## Build an APK without a local Android SDK (GitHub Actions)
1. Create a GitHub repository and upload the contents of this folder to its `main` branch.
2. Open the repository's **Actions** tab and choose **Build Rummy King APK**. If prompted, enable workflows, then click **Run workflow**.
3. Wait for the workflow to finish successfully.
4. Open that workflow run and download the `RummyKing-debug-apk` artifact. Extract it to get `app-debug.apk`.
5. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

The workflow is in `.github/workflows/build-apk.yml`. It compiles a debug APK; it is for testing and is not a signed production release.

## Build locally
1. Install Android Studio and Android SDK API 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Current limitations
- Single-device, offline prototype; no real multiplayer or backend.
- Simplified meld checker; not a tournament-grade Indian rummy rules engine.
- Points and daily claim date are stored locally and can be reset by clearing app data.
- No advertising SDK, analytics, login, or online leaderboard.
- Before public release, add app icon/screenshots, accessibility and device testing, privacy disclosures, and review applicable Google Play policies and local law.
